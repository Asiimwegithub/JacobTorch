package com.jacob.jacobtorch;
import android.annotation.SuppressLint;
import android.content.Context;
import android.hardware.camera2.CameraAccessException;
import android.hardware.camera2.CameraManager;
import android.media.MediaPlayer;
import android.os.Bundle;

import android.widget.CompoundButton;
import android.widget.Toast;
import android.widget.ToggleButton;

import androidx.appcompat.app.AppCompatActivity;

;
import static android.R.color.transparent;


public class MainActivity extends AppCompatActivity {


    private CameraManager Manager;
    private String raId;
    public MediaPlayer sound;
    private ToggleButton toggleButton;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        sound = MediaPlayer.create(this, R.raw.clik);


        Manager = (CameraManager) getSystemService(Context.CAMERA_SERVICE);
        try {
            raId = Manager.getCameraIdList()[0];
        } catch (CameraAccessException e) {
            e.printStackTrace();
        }

        toggleButton = findViewById(R.id.toggleHere);

        toggleButton.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @SuppressLint("ResourceAsColor")
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                FlashLight(isChecked);
                if (isChecked){
                    toggleButton.setBackgroundColor(transparent);
                    Toast.makeText(MainActivity.this, "On", Toast.LENGTH_SHORT).show();
                }
                else {
                    toggleButton.setBackgroundColor(transparent);
                    Toast.makeText(MainActivity.this, "Off", Toast.LENGTH_SHORT).show();

                }
                sound.start();
            }
        });
    }



    public void FlashLight(boolean status) {
        try {
            Manager.setTorchMode(raId, status);
        } catch (CameraAccessException e) {
            e.printStackTrace();
        }
    }
}
